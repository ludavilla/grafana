#!/bin/bash
tar -xzvf /tmp/mysqld_exporter-0.12.1.linux-amd64.tar.gz --directory=/tmp/
mv /tmp/mysqld_exporter-0.12.1.linux-amd64/mysqld_exporter /usr/local/bin/; chown mysqld_exporter:mysqld_exporter /usr/local/bin/mysqld_exporter
