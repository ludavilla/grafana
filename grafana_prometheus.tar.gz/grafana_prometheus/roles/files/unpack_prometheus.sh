#!/bin/bash
tar -xzvf /tmp/prometheus-2.23.0.linux-amd64.tar.gz --directory=/tmp/
mv /tmp/prometheus-2.23.0.linux-amd64 /tmp/prometheus
#useradd --no-create-home --shell /bin/false prometheus
