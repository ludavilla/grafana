#!/bin/bash
IP=`hostname -I`
echo "

- job_name: 'node_exporter_$HOSTNAME'
    scrape_interval: 5s
    static_configs:
      - targets: ['$IP:9100']" >> /etc/prometheus/prometheus.yml
