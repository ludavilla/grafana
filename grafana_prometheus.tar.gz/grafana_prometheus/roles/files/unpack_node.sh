#!/bin/bash
tar -xzvf /tmp/node_exporter-1.0.1.linux-amd64.tar.gz --directory=/tmp/
mv /tmp/node_exporter-1.0.1.linux-amd64/node_exporter /usr/local/bin/
