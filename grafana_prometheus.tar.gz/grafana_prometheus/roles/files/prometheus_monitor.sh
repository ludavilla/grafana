#!/bin/bash
IP=`hostname -I`
echo "

global:
  scrape_interval: 10s

scrape_configs:
  - job_name: 'prometheus_master'
    scrape_interval: 5s
    static_configs:
      - targets: ['$IP:9090']" > /etc/prometheus/prometheus.yml
