#!/bin/bash
#/tmp/prometheus/
cp /tmp/prometheus/prometheus /usr/local/bin/; chown prometheus:prometheus /usr/local/bin/prometheus
cp /tmp/prometheus/promtool /usr/local/bin/; chown prometheus:prometheus /usr/local/bin/promtool
cp -r /tmp/prometheus/consoles /etc/prometheus; chown -R prometheus:prometheus /etc/prometheus/consoles
cp -r /tmp/prometheus/console_libraries /etc/prometheus; chown -R prometheus:prometheus /etc/prometheus/console_libraries
